export default [
  {
    text: '地图展示',
    children: [
      {
        text: '地图展示2',
        path: '/demo1',
      },
      {
        text: '地图展示2',
        path: '/demo2',
      },
     
    ],
  },
  {
    text: '覆盖物',
    children: [
      {
        text: '矢量图标注',
        path: '/symbol',
      },
      {
        text: '行政区域',
        path: '/boundary',
      },
      {
        text: '海量标注',
        path: '/pointcollection',
      },
      {
        text: '地面叠加层',
        path: '/ground',
      },
     
     
    ],
  },
];
